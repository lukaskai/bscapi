export default {
  masterChef: {
    97: '0xbbC5e1cD3BA8ED639b00927115e5f0e0040aA613',
    56: '0x5c8D727b265DBAfaba67E050f2f739cAeEB4A6F9',
  },
  wbnb: {
    97: '0xae13d989dac2f0debff460ac112a837c89baa7cd',
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  },
  busd: {
    97: '0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee',
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  },
};
