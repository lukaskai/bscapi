export default {
  BNB: 'BNB',
  BUSD: 'BUSD',
};
