export default {
  BNB: 'BNB',
  CAKE: 'CAKE',
  SYRUP: 'SYRUP',
  BUSD: 'BUSD',
  TWT: 'TWT',
  UST: 'UST',
  ETH: 'ETH',
  COMP: 'COMP',
};
