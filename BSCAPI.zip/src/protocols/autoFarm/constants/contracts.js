export default {
  masterChef: {
    97: '',
    56: '0x0895196562c7868c5be92459fae7f877ed450452',
  },
};
