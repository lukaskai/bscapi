export default {
  INTERNAL_SERVER_ERROR: 'We are unable to process your response. Please contact support.',
  INVALID_ADDRESS: 'INVALID_ADDRESS',
};
